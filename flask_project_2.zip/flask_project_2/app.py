from flask import Flask, current_app
from flask import (make_response,
                   redirect,
                   abort,
                   session,
                   render_template, 
                   url_for, 
                   flash, 
                   request)
##
## Flask extensions imports
##
from flask_script import Manager
from flask_bootstrap import Bootstrap
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate, MigrateCommand
from flask_wtf import FlaskForm
from wtforms import (StringField, 
    SubmitField, IntegerField, FloatField, SelectField)
from wtforms.validators import (DataRequired, 
    InputRequired, Length, NumberRange)

import config
import joblib
loaded_model = joblib.load("model_saved1")
app = Flask(__name__, template_folder="templates")
Bootstrap(app)
app.config.from_object('config')
app.config["SECRET_KEY"] = "hard to guess string"


manager = Manager(app) # To give provide CLI commands
#bootstrap = Bootstrap(app) # Twitter Bootstrap extension
db = SQLAlchemy(app) # SQLAlchemy extension, manipulating the database object db
migrate = Migrate(app, db) # database migrations
manager.add_command('db', MigrateCommand) # to add it as command line using Flask Script




class EnterNews(FlaskForm):
    url = StringField("Url", validators=[DataRequired()])
    day = SelectField("Choose the day of publication : ", choices=[(0,"Lundi"), (1,"Mardi"), (2,"Mercredi"), (3,"Jeudi"), (4,"Vendredi"),(5,"Samedi"),(6,"Dimanche")], coerce=int, validators=[InputRequired()])
    data_channel = SelectField("Choose the data channel :", choices=[(0,"Lifestyle"), (1,"Entertainment"), (2, "Business"), (3, "Social Media"), (4, "Tech"), (5, "World")], coerce=int, validators=[InputRequired()])
    n_tokens_title = IntegerField("Enter the number of words in the title : ", validators=[DataRequired(), NumberRange(min=0, max=50)])
    n_img = IntegerField("Enter the number of images in the content :", validators=[DataRequired(), NumberRange(min=0,max=50)])
    n_vid = IntegerField("Enter the number of videos in the content:", validators=[DataRequired(), NumberRange(min=0,max=50)])
    submit = SubmitField("Submit")


class OnlineNews(db.Model):
    __tablename__ = "articles"
    id_ = db.Column(db.Integer, primary_key=True)
    url = db.Column(db.String(200), unique=True)
    day = db.Column(db.String(64))
    data_channel = db.Column(db.String(64))
    n_tokens_title = db.Column(db.Integer, nullable=False)
    n_img = db.Column(db.Integer)
    n_vid = db.Column(db.Integer)
    shares = db.Column(db.Integer)

    
#views

@app.route("/")
def index():
    #return f"<h1>oui</h1>",200
    #return render_template("oui.html")
    return render_template("index.html")

@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html', nompath=e), 404

@app.route('/predict', methods=['GET', 'POST'])
def predict():
    form = EnterNews()
    if request.method=="POST" and form.validate_on_submit():
        # check if a user with the same name already exist in the db
        news = OnlineNews.query.filter_by(url=form.url.data).first()
        if news is not None:
            flash('It seems like this article has already been evaluated, this was your prediction: {}'.format(
                news.shares))
        else:
            # predict shares
            prediction = int(loaded_model.predict(
                [[form.n_tokens_title.data, form.n_img.data, form.n_vid.data]]
            ))
            #print(form.n_tokens_title.data, form.n_img.data, form.n_vid.data,'truc')
            # create a new "user" of the service
            news = OnlineNews(url=form.url.data, 
                    n_tokens_title=form.n_tokens_title.data, 
                    n_img=form.n_img.data,
                    n_vid=form.n_vid.data,
                    shares=prediction)
            # add the user to the db
            db.session.add(news)
            db.session.commit()
        session["shares"] = news.shares
        return render_template('results.html', prediction=prediction)
    return render_template('predict.html', form=form)

@app.route('/results')
def show_result():
    return f"<h1>Your article could be shared </1>"
    #return render_template('results.html', success=session.get('shares', 'first'))

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)


