# -*- coding: utf-8 -*-
"""
Created on Sat Jan  9 16:03:53 2021

@author: lalai
"""

from app import db
db.create_all()